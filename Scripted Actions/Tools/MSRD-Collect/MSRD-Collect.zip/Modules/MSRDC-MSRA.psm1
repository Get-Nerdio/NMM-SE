<#
.SYNOPSIS
   Scenario module for collecting Microsoft Remote Assistance and Quick Assist / RemoteHelp related data

.DESCRIPTION
   Collect Remote Assistance related troubleshooting data

.NOTES
   Author     : Robert Klemencz
   Requires   : MSRD-Collect.ps1
   Version    : See MSRD-Collect.ps1 version
   Feedback   : https://aka.ms/MSRD-Collect-Feedback
#>

$msrdLogPrefix = "MSRA"
$msrdRemoteAssist = $global:msrdBasicLogFolder + "RemoteAssist\"

$msrdUserProfilesDir = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList" -Name ProfilesDirectory).ProfilesDirectory

Function msrdGetRemoteHelpData {

    msrdLogMessage $LogLevel.Normal -LogPrefix $msrdLogPrefix -Message "Collecting Remote Help installation logs"

    $rhlogcount = 0
    foreach ($userProfile in Get-ChildItem -Path $msrdUserProfilesDir -Directory -ErrorAction SilentlyContinue) {
        $tempPath = Join-Path $userProfile.FullName "AppData\Local\Temp"

        # Find MSI*.log files containing the specified string
        $filesToCopy = Get-ChildItem -Path $tempPath -Filter "Remote_help*.log" -Recurse -ErrorAction SilentlyContinue | Where-Object { Get-Content $_.FullName }

        if ($filesToCopy) {
            # Copy the files to the destination with modified names
            foreach ($file in $filesToCopy) {
                $fileName = $file.Name
                $modifiedFileName = $global:msrdLogFilePrefix + $fileName
                $destinationFile = Join-Path $msrdRemoteAssist $modifiedFileName
                Copy-Item $file.FullName -Destination $destinationFile -Force
            }
            $rhlogcount += 1
        }
    }
    if ($rhlogcount -eq 0) {
        msrdLogMessage $LogLevel.InfoLogFileOnly -LogPrefix $msrdLogPrefix -Message "No Remote Help installation logs found"
    }

    msrdCreateLogFolder $global:msrdEventLogFolder
    $logs = @{
        'Microsoft-Windows-RemoteHelp/Operational' = 'RemoteHelp-Operational'
    }
    msrdGetEventLogs -LogPrefix $msrdLogPrefix -EventHashtable $logs

    $Commands = @(
        "Get-WinEvent -LogName Microsoft-Windows-RemoteHelp/Operational | Where-Object -Property Message -like '*sendcvtonativeapp*' | Format-Table TimeCreated, Message -Wrap -Auto | Out-File -Append '" + $msrdRemoteAssist + $global:msrdLogFilePrefix + "RemoteHelp-CorrelationVectorHistory.txt'"
    )
    msrdRunCommands -LogPrefix $msrdLogPrefix -CmdletArray $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
}

Function msrdGetMSRAGroupsMembership {

    msrdGetLocalGroupMembership -logPrefix $msrdLogPrefix -groupName "Offer Remote Assistance Helpers" -outputFile ($msrdRemoteAssist + $global:msrdLogFilePrefix + "LocalGroupsMembership.txt")
    msrdGetLocalGroupMembership -logPrefix $msrdLogPrefix -groupName "Distributed COM Users" -outputFile ($msrdRemoteAssist + $global:msrdLogFilePrefix + "LocalGroupsMembership.txt")
}

Function msrdGetMSRAEventLogs {

    msrdCreateLogFolder $global:msrdEventLogFolder
    $logs = @{
        'Microsoft-Windows-RemoteAssistance/Admin' = 'RemoteAssistance-Admin'
        'Microsoft-Windows-RemoteAssistance/Operational' = 'RemoteAssistance-Operational'
    }
    msrdGetEventLogs -LogPrefix $msrdLogPrefix -EventHashtable $logs
}

Function GetMSRARegKeys {

    msrdCreateLogFolder $global:msrdRegLogFolder
    $regs = @{
        'HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance' = 'System-CCS-Control-MSRA'
    }
    msrdGetRegKeys -LogPrefix $msrdLogPrefix -RegHashtable $regs
}

Function msrdGetMSRAPermissions {

    $Reg = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey("Software\Microsoft\Ole", $false)
    $DCOMMachineLaunchRestriction = $Reg.GetValue("MachineLaunchRestriction")
    $DCOMMachineAccessRestriction = $Reg.GetValue("MachineAccessRestriction")
    $DCOMDefaultLaunchPermission = $Reg.GetValue("DefaultLaunchPermission")
    $DCOMDefaultAccessPermission = $Reg.GetValue("DefaultAccessPermission")

    # Convert the current permissions to SDDL
    $converter = new-object system.management.ManagementClass Win32_SecurityDescriptorHelper
    "Default Access Permission = " + ($converter.BinarySDToSDDL($DCOMDefaultAccessPermission)).SDDL | Out-File -Append ($msrdRemoteAssist + $global:msrdLogFilePrefix + "COMSecurity.txt")
    "Default Launch Permission = " + ($converter.BinarySDToSDDL($DCOMDefaultLaunchPermission)).SDDL | Out-File -Append ($msrdRemoteAssist + $global:msrdLogFilePrefix + "COMSecurity.txt")
    "Machine Access Restriction = " + ($converter.BinarySDToSDDL($DCOMMachineAccessRestriction)).SDDL | Out-File -Append ($msrdRemoteAssist + $global:msrdLogFilePrefix + "COMSecurity.txt")
    "Machine Launch Restriction = " + ($converter.BinarySDToSDDL($DCOMMachineLaunchRestriction)).SDDL | Out-File -Append ($msrdRemoteAssist + $global:msrdLogFilePrefix + "COMSecurity.txt")
}

Function msrdGetMSRASchedTasks {

    if ($ScheduledTasks = Get-ScheduledTask -TaskPath '\Microsoft\Windows\RemoteAssistance\' -ErrorAction Ignore) {
        $ScheduledTasks | ForEach-Object -Process {
            $Commands = @(
                "Export-ScheduledTask -TaskName $($_.TaskName) -TaskPath '\Microsoft\Windows\RemoteAssistance' 2>&1 | Out-File -Append '" + $msrdRemoteAssist + $global:msrdLogFilePrefix + "schtasks_" + $_.TaskName + ".xml'"
                "Get-ScheduledTaskInfo -TaskName $($_.TaskName) -TaskPath '\Microsoft\Windows\RemoteAssistance' 2>&1 | Out-File -Append '" + $msrdRemoteAssist + $global:msrdLogFilePrefix + "schtasks_" + $_.TaskName + "_Info.txt'"
            )
            msrdRunCommands -LogPrefix $msrdLogPrefix -CmdletArray $Commands -ThrowException:$False -ShowMessage:$True -ShowError:$True
        }
    } else {
        msrdLogMessage $LogLevel.WarnLogFileOnly -LogPrefix $msrdLogPrefix -Message "Remote Assistance Scheduled Tasks not found"
    }
}

# Collecting Remote Assistance troubleshooting data
Function msrdCollectUEX_AVDMSRALog {
    param( [bool[]]$varsMSRA )

    if ($true -contains $varsMSRA) {
        if ($global:msrdSilentMode -eq 1) { msrdLogMessage $LogLevel.Normal "`n" -NoDate } else { " " | Out-File -Append $global:msrdOutputLogFile }
        msrdLogMessage $LogLevel.Info "$(msrdGetLocalizedText "msramsg")" -silentException
        msrdCreateLogFolder $msrdRemoteAssist
    }

    if ($global:msrdTarget) {
        if ($varsMSRA[0]) {
            if ($global:msrdAudioAssistMode -eq 1) { msrdLogMessageAssistMode "Collect Remote Assistance event logs" }
            msrdGetMSRAEventLogs
        } #get event logs

        if ($varsMSRA[1]) {
            if ($global:msrdAudioAssistMode -eq 1) { msrdLogMessageAssistMode "Collect Remote Assistance registry keys" }
            GetMSRARegKeys
        } #get reg keys

        if ($varsMSRA[2]) {
            if ($global:msrdAudioAssistMode -eq 1) { msrdLogMessageAssistMode "Collect Remote Assistance groups membership" }
            msrdGetMSRAGroupsMembership
        } #get groups membership

        if ($varsMSRA[3]) {
            if ($global:msrdAudioAssistMode -eq 1) { msrdLogMessageAssistMode "Collect Remote Assistance permissions" }
            msrdGetMSRAPermissions
        } #get permissions

        if ($varsMSRA[4]) {
            if ($global:msrdAudioAssistMode -eq 1) { msrdLogMessageAssistMode "Collect Remote Assistance scheduled tasks" }
            msrdGetMSRASchedTasks
        } #get scheduled tasks
    }

    if ($varsMSRA[5]) {
		if ($global:msrdAudioAssistMode -eq 1) { msrdLogMessageAssistMode "Collect Remote Help installation and event logs" }
		msrdGetRemoteHelpData
	} #get Remote Help data

    if ($varsMSRA[6]) {
        $ProfilesLogFolder = $global:msrdBasicLogFolder + "Profiles\"
        msrdCreateLogFolder $ProfilesLogFolder
        if ($global:msrdAudioAssistMode -eq 1) { msrdLogMessageAssistMode "Collect WhoAmI information" }
        msrdRunCommands -LogPrefix $msrdLogPrefix -CmdletArray ("Whoami /all 2>&1 | Out-File -Append '" + $ProfilesLogFolder + $global:msrdLogFilePrefix + "WhoAmI-all.txt'") -ThrowException:$False -ShowMessage:$True -ShowError:$True
    } #get whoami
}


Export-ModuleMember -Function msrdCollectUEX_AVDMSRALog
# SIG # Begin signature block
# MIIoUgYJKoZIhvcNAQcCoIIoQzCCKD8CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBwnPRg4+xpx29b
# RLQ4I9gTh5MBVlruIlyFrSXLOQcYDKCCDYUwggYDMIID66ADAgECAhMzAAADri01
# UchTj1UdAAAAAAOuMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwODU5WhcNMjQxMTE0MTkwODU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQD0IPymNjfDEKg+YyE6SjDvJwKW1+pieqTjAY0CnOHZ1Nj5irGjNZPMlQ4HfxXG
# yAVCZcEWE4x2sZgam872R1s0+TAelOtbqFmoW4suJHAYoTHhkznNVKpscm5fZ899
# QnReZv5WtWwbD8HAFXbPPStW2JKCqPcZ54Y6wbuWV9bKtKPImqbkMcTejTgEAj82
# 6GQc6/Th66Koka8cUIvz59e/IP04DGrh9wkq2jIFvQ8EDegw1B4KyJTIs76+hmpV
# M5SwBZjRs3liOQrierkNVo11WuujB3kBf2CbPoP9MlOyyezqkMIbTRj4OHeKlamd
# WaSFhwHLJRIQpfc8sLwOSIBBAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUhx/vdKmXhwc4WiWXbsf0I53h8T8w
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzUwMTgzNjAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AGrJYDUS7s8o0yNprGXRXuAnRcHKxSjFmW4wclcUTYsQZkhnbMwthWM6cAYb/h2W
# 5GNKtlmj/y/CThe3y/o0EH2h+jwfU/9eJ0fK1ZO/2WD0xi777qU+a7l8KjMPdwjY
# 0tk9bYEGEZfYPRHy1AGPQVuZlG4i5ymJDsMrcIcqV8pxzsw/yk/O4y/nlOjHz4oV
# APU0br5t9tgD8E08GSDi3I6H57Ftod9w26h0MlQiOr10Xqhr5iPLS7SlQwj8HW37
# ybqsmjQpKhmWul6xiXSNGGm36GarHy4Q1egYlxhlUnk3ZKSr3QtWIo1GGL03hT57
# xzjL25fKiZQX/q+II8nuG5M0Qmjvl6Egltr4hZ3e3FQRzRHfLoNPq3ELpxbWdH8t
# Nuj0j/x9Crnfwbki8n57mJKI5JVWRWTSLmbTcDDLkTZlJLg9V1BIJwXGY3i2kR9i
# 5HsADL8YlW0gMWVSlKB1eiSlK6LmFi0rVH16dde+j5T/EaQtFz6qngN7d1lvO7uk
# 6rtX+MLKG4LDRsQgBTi6sIYiKntMjoYFHMPvI/OMUip5ljtLitVbkFGfagSqmbxK
# 7rJMhC8wiTzHanBg1Rrbff1niBbnFbbV4UDmYumjs1FIpFCazk6AADXxoKCo5TsO
# zSHqr9gHgGYQC2hMyX9MGLIpowYCURx3L7kUiGbOiMwaMIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGiMwghofAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAAOuLTVRyFOPVR0AAAAA
# A64wDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIBp5
# wpOcBa4bwqNELsrF6xTU4uL0xLgG/KxRoBJm8D6DMEIGCisGAQQBgjcCAQwxNDAy
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20wDQYJKoZIhvcNAQEBBQAEggEARLWV2CRMpFmxx0S1ZWsj6XtKOyQq/Uc0OBJO
# aFwypXH9T1FqaPk/Rp8adCYPRzwfMwQ80v6y20Aoquc8/2XWOBH2gPUNhbwDAepK
# CMwEBxIJl7/S257/wFiw1kJHTaDOMGqpAZ0aFq4PiQg27ywNs8+++AgLZpvBv/Zw
# 5j/9i6q95tSJ+OIVUn0BhqUuZAGXGmmmp4qYEhKtc24aNTa1RksMcI+/Gy+xHoqb
# X7l7z2zqU48FYokmqcf5A0l3rTGT+ZVlOZuJ+xZ7dz2tzdbjFmPPtlu5eYgwCEmx
# ZDnpNzS+uA4cfKbvyW/nPP8QcOO77efJRm7gCnj/tJ7VdYMrsqGCF60wghepBgor
# BgEEAYI3AwMBMYIXmTCCF5UGCSqGSIb3DQEHAqCCF4YwgheCAgEDMQ8wDQYJYIZI
# AWUDBAIBBQAwggFaBgsqhkiG9w0BCRABBKCCAUkEggFFMIIBQQIBAQYKKwYBBAGE
# WQoDATAxMA0GCWCGSAFlAwQCAQUABCDzHIfMqG/kWL2lDmIdoL3qM/838LkCICoL
# fLUHGue7lAIGZut1zastGBMyMDI0MDkyNzA3MzgwMi4wOTRaMASAAgH0oIHZpIHW
# MIHTMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQL
# EyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsT
# Hm5TaGllbGQgVFNTIEVTTjo2NTFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgU2VydmljZaCCEfswggcoMIIFEKADAgECAhMzAAAB9ZkJ
# lLzxxlCMAAEAAAH1MA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMB4XDTI0MDcyNTE4MzEwMVoXDTI1MTAyMjE4MzEwMVowgdMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jv
# c29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVs
# ZCBUU1MgRVNOOjY1MUEtMDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBTZXJ2aWNlMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# zO90cFQTWd/WP84IT7JMIW1fQL61sdfgmhlfT0nvYEb2kvkNF073ZwjveuSWot38
# 7LjE0TCiG93e6I0HzIFQBnbxGP/WPBUirFq7WE5RAsuhNfYUL+PIb9jJq3CwWxIC
# fw5t/pTyIOHjKvo1lQOTWZypir/psZwEE7y2uWAPbZJTFrKen5R73x2Hbxy4eW1D
# cmXjym2wFWv10sBH40ajJfe+OkwcTdoYrY3KkpN/RQSjeycK0bhjo0CGYIYa+ZMA
# ao0SNR/R1J1Y6sLkiCJO3aQrbS1Sz7l+/qJgy8fyEZMND5Ms7C0sEaOvoBHiWSpT
# M4vc0xDLCmc6PGv03CtWu2KiyqrL8BAB1EYyOShI3IT79arDIDrL+de91FfjmSbB
# Y5j+HvS0l3dXkjP3Hon8b74lWwikF0rzErF0n3khVAusx7Sm1oGG+06hz9XAy3Wo
# u+T6Se6oa5LDiQgPTfWR/j9FNk8Ju06oSfTh6c03V0ulla0Iwy+HzUl+WmYxFLU0
# PiaXsmgudNwVqn51zr+Bi3XPJ85wWuy6GGT7nBDmXNzTNkzK98DBQjTOabQXUZ88
# 4Yb9DFNcigmeVTYkyUXZ6hscd8Nyq45A3D3bk+nXnsogK1Z7zZj6XbGft7xgOYvv
# eU6p0+frthbF7MXv+i5qcD9HfFmOq4VYHevVesYb6P0CAwEAAaOCAUkwggFFMB0G
# A1UdDgQWBBRV4Hxb9Uo0oHDwJZJe22ixe2B1ATAfBgNVHSMEGDAWgBSfpxVdAF5i
# XYP05dJlpxtTNRnpcjBfBgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jv
# c29mdC5jb20vcGtpb3BzL2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENB
# JTIwMjAxMCgxKS5jcmwwbAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRp
# bWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBYGA1Ud
# JQEB/wQMMAoGCCsGAQUFBwMIMA4GA1UdDwEB/wQEAwIHgDANBgkqhkiG9w0BAQsF
# AAOCAgEAcwxmVPaA9xHffuom0TOSp2hspuf1G0cHW/KXHAuhnpW8/Svlq5j9aKI/
# 8/G6fGIQMr0zlpau8jy83I4zclGdJjl5S02SxDlUKawtWvgf7ida06PgjeQM1eX4
# Lut4bbPfT0FEp77G76hhysXxTJNHv5y+fwThUeiiclihZwqcZMpa46m+oV6igTU6
# I0EnneotMqFs0Q3zHgVVr4WXjnG2Bcnkip42edyg/9iXczqTBrEkvTz0UlltpFGa
# QnLzq+No8VEgq0UG7W1ELZGhmmxFmHABwTT6sPJFV68DfLoC0iB9Qbb9VZ8mvbTV
# 5JtISBklTuVAlEkzXi9LIjNmx+kndBfKP8dxG/xbRXptQDQDaCsS6ogLkwLgH6zS
# s+ul9WmzI0F8zImbhnZhUziIHheFo4H+ZoojPYcgTK6/3bkSbOabmQFf95B8B6e5
# WqXbS5s9OdMdUlW1gTI1r5u+WAwH2KG7dxneoTbf/jYl3TUtP7AHpyck2c0nun/Q
# 0Cycpa9QUH/Dy01k6tQomNXGjivg2/BGcgZJ0Hw8C6KVelEJ31xLoE21m9+NEgSK
# CRoFE1Lkma31SyIaynbdYEb8sOlZynMdm8yPldDwuF54vJiEArjrcDNXe6BobZUi
# TWSKvv1DJadR1SUCO/Od21GgU+hZqu+dKgjKAYdeTIvi9R2rtLYwggdxMIIFWaAD
# AgECAhMzAAAAFcXna54Cm0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3Nv
# ZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5MzAxODIy
# MjVaFw0zMDA5MzAxODMyMjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciELeaLL1yR5
# vQ7VgtP97pwHB9KpbE51yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64
# NmeFRiMMtY0Tz3cywBAY6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxRMTegCjhu
# je3XD9gmU3w5YQJ6xKr9cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEBydUv626GIl
# 3GoPz130/o5Tz9bshVZN7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi947SHJMPg
# yY9+tVSP3PoFVZhtaDuaRr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJiss254o2I
# 5JasAUq7vnGpF1tnYN74kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/NmeRd+2
# ci/bfV+AutuqfjbsNkz2K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY7afomXw/
# TNuvXsLz1dhzPUNOwTM5TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy
# 16cg8ML6EgrXY28MyTZki1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH29wb0f2y
# 1BzFa/ZcUlFdEtsluq9QBXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6H
# XtqPnhZyacaue7e3PmriLq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcVAQQFAgMB
# AAEwIwYJKwYBBAGCNxUCBBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQW
# BBSfpxVdAF5iXYP05dJlpxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQBgjdMg30B
# ATBBMD8GCCsGAQUFBwIBFjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L0RvY3MvUmVwb3NpdG9yeS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgwGQYJKwYB
# BAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMB
# Af8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBL
# oEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMv
# TWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggr
# BgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNS
# b29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1Vffwq
# reEsH2cBMSRb4Z5yS/ypb+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRsfNB1OW27
# DzHkwo/7bNGhlBgi7ulmZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6Ce5732pv
# vinLbtg/SHUB2RjebYIM9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveVtihVJ9Ak
# vUCgvxm2EhIRXT0n4ECWOKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWK
# NsIdw2FzLixre24/LAl4FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoyGtmW9I/2
# kQH2zsZ0/fZMcm8Qq3UwxTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQEcb9k+SS+
# c23Kjgm9swFXSVRk2XPXfx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pFEUep
# 8beuyOiJXk+d0tBMdrVXVAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+k77L+Dvk
# txW/tM4+pTFRhLy/AsGConsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1Zyvg
# DbjmjJnW4SLq8CdCPSWU5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cirOoo6CGJ/
# 2XBjU02N7oJtpQUQwXEGahC0HVUzWLOhcGbyoYIDVjCCAj4CAQEwggEBoYHZpIHW
# MIHTMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQL
# EyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsT
# Hm5TaGllbGQgVFNTIEVTTjo2NTFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAJsAKu48NbR5Y
# Rg3WSBQCyjzdkvaggYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MDANBgkqhkiG9w0BAQsFAAIFAOqgf+QwIhgPMjAyNDA5MjcwMDUwNDRaGA8yMDI0
# MDkyODAwNTA0NFowdDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA6qB/5AIBADAHAgEA
# AgILkjAHAgEAAgITvTAKAgUA6qHRZAIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgor
# BgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBCwUA
# A4IBAQAwla192jhGv7mFRvacq6inlMtXjgAyGJ1T8K4/22E6KdZ3IfJdG41WCKJ/
# jOo8NC8fPVEbnT2gMGgYXJ99jG6V5hgmLNFuN9seDx0uLopWwdnxVsjkNcE4WL3Z
# 9eFEOvSwPrhZcg+xXnO3o5qoPzqqsAb4n3qCIyRRB2U+6OKhf7/IAUCB9MYFuSyz
# DblRjRMKxr1gljxBPsLxPLiaF+zCu1lT9bKbHccVSe08hTQCasQ+w8HM5uAVZEsx
# oTZwXmPoye6jn2y+JgCf3RW3mwmmGeDx3t/GF+HmbMJplSfu6FdnVy113i82hJIO
# 2cft6LfTE6IivJbEH623Qi05l1YsMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAH1mQmUvPHGUIwAAQAAAfUwDQYJYIZIAWUD
# BAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0B
# CQQxIgQgxWGPq/QRoys97AFh2s2P3DHrcbWCW82+SqN27xbVoaowgfoGCyqGSIb3
# DQEJEAIvMYHqMIHnMIHkMIG9BCDB1vLSFwh09ISu4kdEv4/tg9eR1Yk8w5x7j5GT
# hqaPNTCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# 9ZkJlLzxxlCMAAEAAAH1MCIEIDLlYN5PcchetOnhg9XaXvUrYVz81lyWYjJ3wtNE
# Qwy6MA0GCSqGSIb3DQEBCwUABIICAKfv88c/MPzqT2SbD8IIuFgLNNlRpSAggNFB
# /vW3IDOPFgifn2xyMtqIxnCrK5yzPS1jwJV6eTWn/nrXs8ZG9s68365OYzzStNhf
# vYW8vC02jucm/AHfDljaiXO3RGgSuCIfP6CoC3chihL04IoMtIxd7YYni/UwSklH
# A3z23ORmSFEh4aNvj7pVt3z2l/cl/oqug6kpQPi1k7XJbTRet+Odv390iI0MNwB+
# 0Kj3snkc5scS0pQaGHonWITgvRnDD6MsVN5ulp2gniSaWWkKwM2kvgJUuCObBM7f
# 9i/5RO3Mweo366P9cnf5yf0XRBsR6pw2GhuNmVTJijB3NNNWG99NIA53NAIMPU2A
# iCEUJ36IJnG38jNW4UcLmGge98ejyZ1TXxGAby3EEnn2iE97pK32E0OjTIE9JzhE
# B5qP1Ga4ZMy5dCUPo07Y0ck7HEKXkvZl66wL9TFo5LfJDikJDZ01BZ86srpIvGjJ
# C9f4R1/WCBYu7fN1bzH97Y5iPyRhlgZM9iUiFbzvHWFbcxOn2DDlCc29mP3Tr1i2
# 6bKTauwnjHuy84Cj3szFleaSNNVqZtU1Mr8EZ/xlzEMpaGqBO/AJtoUMmbv5E0uZ
# y+6wnqDCzQLxeAaSZar5ETs/pFBGnhVQ4Tg8lpK987aogHA/2oK6csoTfsOStan7
# WpDcxE55
# SIG # End signature block
