﻿<#
.SYNOPSIS
   MSRD-Collect graphical user interface (Lite version)

.DESCRIPTION
   Module for the MSRD-Collect graphical user interface (Lite version)

.NOTES
   Author     : Robert Klemencz
   Requires   : MSRD-Collect.ps1
   Version    : See MSRD-Collect.ps1 version
   Feedback   : https://aka.ms/MSRD-Collect-Feedback
#>

#region config variables
$script:varsCore = @(,$true * 12); $script:vCore = $script:varsCore

$script:varsProfiles = @(,$true * 5)
$script:varsActivation = @(,$true * 3)
$script:varsMSRA = @(,$true * 7)
$script:varsSCard = @(,$true * 3)
$script:varsIME = @(,$true * 3)
$script:varsTeams = @(,$true * 4)
$script:varsMSIXAA = @(,$true * 1)
$script:varsHCI = @(,$true * 1)

$script:varsSystem = @(,$true * 13)
$script:varsAVDRDS = @(,$true * 11)
$script:varsInfra = @(,$true * 10)
$script:varsAD = @(,$true * 2)
$script:varsNET = @(,$true * 8)
$script:varsLogSec = @(,$true * 3)
$script:varsIssues = @(,$true * 2)
$script:varsOther = @(,$true * 4)

$script:varsNO = $false

$script:dumpProc = $False; $script:pidProc = ""
$script:traceNet = $False; $global:onlyDiag = $false

if (@("Prod", "Insider") -contains $global:msrdConfig.DevLevel) {
    $global:msrdConfig.DevLevel = $global:msrdConfig.DevLevel
} else {
    Write-Warning "Unsupported value found for 'DevLevel' in Config\MSRDC-Config.json. Supported values are Prod or Insider. Exiting."
	Exit 1
}

#endregion config variables


#region GUI functions

function msrdStartBtnCollect {
    if (-not $global:btnTeamsClick) {
        $TeamsLogs = msrdGetLocalizedText "teamsnote"
        $wshell = New-Object -ComObject Wscript.Shell
        $teamstitle = msrdGetLocalizedText "teamstitle"
        $answer = $wshell.Popup("$TeamsLogs",0,"$teamstitle",5+48)
        if ($answer -eq 4) { $GetTeamsLogs = $false } else { $GetTeamsLogs = $true }
    } else {
        $GetTeamsLogs = $false
    }

    msrdInitFolders

    if (-not $GetTeamsLogs) {
        $btnStart.Text = msrdGetLocalizedText "Running"
        if (-not $global:onlyDiag) {
            $global:msrdStatusBarLabel.Text = msrdGetLocalizedText "rdcmsg"
        } else {
			$global:msrdStatusBarLabel.Text = msrdGetLocalizedText "rdiagmsg"
		}

        msrdLogMessage $LogLevel.InfoLogFileOnly "$(msrdGetLocalizedText initvalues1a) $global:msrdVersion $(msrdGetLocalizedText initvalues1b) $global:msrdScriptpath ($global:msrdAccountLevel)"
        msrdLogMessage $LogLevel.InfoLogFileOnly "$(msrdGetLocalizedText initvalues1c) $global:msrdCmdLine"
        msrdLogMessage $LogLevel.InfoLogFileOnly "$(msrdGetLocalizedText initvalues2)"
        msrdLogMessage $LogLevel.InfoLogFileOnly "$(msrdGetLocalizedText initvalues3) $global:msrdLogRoot"
        msrdLogMessage $LogLevel.InfoLogFileOnly "$(msrdGetLocalizedText initvalues4) $global:msrdUserprof`n"
        msrdLogMessage $LogLevel.InfoLogFileOnly "$(msrdGetLocalizedText dpidtext3) $script:pidProc"

        $selectedScenarios = @()

        $checkboxes = @(
            $TbAVD, $TbRDS, $TbW365,
            $TbSource, $TbTarget,
            $TbCore, $TbProfiles, $TbActivation, $TbMSRA, $TbSCard, $TbIME, $TbTeams, $TbMSIXAA, $TbHCI, $TbProcDump, $TbNetTrace, $TbDiagOnly
        )

        foreach ($checkbox in $checkboxes) {
            if ($checkbox.Checked) {
                $selectedScenarios += $checkbox.Text
            }
        }

        $selectedScenariosString = $selectedScenarios -join ", "

        msrdLogMessage $LogLevel.InfoLogFileOnly "Selected parameters for data collection/diagnostics: $selectedScenariosString`n"

        if (-not $global:onlyDiag) {
            #data collection
            $parameters = @{
                varsCore = $script:vCore
                varsProfiles = $script:vProfiles
                varsActivation = $script:vActivation
                varsMSRA = $script:vMSRA
                varsSCard = $script:vSCard
                varsIME = $script:vIME
                varsTeams = $script:vTeams
                varsMSIXAA = $script:vMSIXAA
                varsHCI = $script:vHCI
                traceNet = $script:traceNet
                dumpProc = $script:dumpProc
                pidProc = $script:pidProc
            }
            msrdCollectData @parameters
        }

        #diagnostics
        $parameters = @{
            varsSystem = $script:varsSystem
            varsAVDRDS = $script:varsAVDRDS
            varsInfra = $script:varsInfra
            varsAD = $script:varsAD
            varsNET = $script:varsNET
            varsLogSec = $script:varsLogSec
            varsIssues = $script:varsIssues
            varsOther = $script:varsOther
        }
        msrdCollectDataDiag @parameters

        $global:msrdStatusBarLabel.Text = msrdGetLocalizedText "archmsg"
        msrdArchiveData -varsCore $script:vCore
        $btnStart.Text = msrdGetLocalizedText "Start"
        $global:msrdStatusBarLabel.Text = msrdGetLocalizedText "Ready"
    }
}

Function msrdInitMachines {
    param ([bool[]]$Machine = @($false, $false, $false))

    if ($Machine[0]) { $global:msrdAVD = $true; $global:msrdRDS = $False; $global:msrdW365 = $False }
    elseif ($Machine[1]) { $global:msrdAVD = $False; $global:msrdRDS = $true; $global:msrdW365 = $False }
    elseif ($Machine[2]) { $global:msrdAVD = $False; $global:msrdRDS = $False; $global:msrdW365 = $true }
    else { $global:msrdAVD = $false; $global:msrdRDS = $false; $global:msrdW365 = $False }
}

Function msrdInitRoles {
    param ([bool[]]$Role = @($false, $false))

    if ($Role[0]) { $global:msrdSource = $true; $global:msrdTarget = $False }
    elseif ($Role[1]) { $global:msrdSource = $False; $global:msrdTarget = $true }
    else {
        $global:msrdSource = $false; $global:msrdTarget = $false
    }
}

Function msrdShowHideItems {
    param ($category, $show=$false)

    if ($category -eq "Role") {
        if ($show) {
			$roleLabel.Visible = $true; $btnSource.Visible = $true; $btnTarget.Visible = $true
            $scenarioLabel.Visible = $false; $btnCore.Visible = $false; $btnDiagOnly.Visible = $false
            $btnProfiles.Visible = $false; $btnActivation.Visible = $false; $btnMSRA.Visible = $false; $btnSCard.Visible = $false; $btnIME.Visible = $false; $btnTeams.Visible = $false; $btnMSIXAA.Visible = $false; $btnHCI.Visible = $false
            $btnStart.Visible = $false
		} else {
			$roleLabel.Visible = $false; $btnSource.Visible = $false; $btnTarget.Visible = $false
            $scenarioLabel.Visible = $false; $btnCore.Visible = $false; $btnDiagOnly.Visible = $false
            $btnProfiles.Visible = $false; $btnActivation.Visible = $false; $btnMSRA.Visible = $false; $btnSCard.Visible = $false; $btnIME.Visible = $false; $btnTeams.Visible = $false; $btnMSIXAA.Visible = $false; $btnHCI.Visible = $false
            $btnStart.Visible = $false
		}
    } elseif ($category -eq "Scenario") {
		if ($show) {
            $scenarioLabel.Visible = $true; $btnCore.Visible = $true; $btnDiagOnly.Visible = $true
            $btnProfiles.Visible = $true; $btnActivation.Visible = $true; $btnMSRA.Visible = $true; $btnSCard.Visible = $true; $btnIME.Visible = $true; $btnTeams.Visible = $true; $btnMSIXAA.Visible = $true; $btnHCI.Visible = $true
            $btnStart.Visible = $true
        } else {
            $scenarioLabel.Visible = $false; $btnCore.Visible = $false; $btnDiagOnly.Visible = $false
            $btnProfiles.Visible = $false; $btnActivation.Visible = $false; $btnMSRA.Visible = $false; $btnSCard.Visible = $false; $btnIME.Visible = $false; $btnTeams.Visible = $false; $btnMSIXAA.Visible = $false; $btnHCI.Visible = $false
            $btnStart.Visible = $false
        }
    } elseif ($category -eq "Start") {
        if ($show) {
			$startLabel.Visible = $true
		} else {
			$startLabel.Visible = $false
		}
	}

}

#endregion GUI functions

Function msrdAVDCollectGUILite {

    $global:msrdGUIformLite = New-Object System.Windows.Forms.Form

    $global:msrdGUIformLite.Size = New-Object System.Drawing.Size(630, 500)
    $global:msrdGUIformLite.StartPosition = "CenterScreen"
    $global:msrdGUIformLite.BackColor = "#eeeeee"
    $global:msrdGUIformLite.MaximizeBox = $false
    $global:msrdGUIformLite.Icon = ([System.IconExtractor]::Extract("$global:msrdScriptpath\Config\MSRDC-Icons.dll", 12, $true))
    if ($global:msrdConfig.DevLevel -eq "Insider") {
        $global:msrdGUIformLite.Text = 'MSRD-Collect Lite (v' + $global:msrdVersion + ') INSIDER Build - For Testing Purposes Only !'
    } else {
        $global:msrdGUIformLite.Text = 'MSRD-Collect Lite (v' + $global:msrdVersion + ')'
    }
    $global:msrdGUIformLite.TopLevel = $true
    $global:msrdGUIformLite.TopMost = $false
    $global:msrdGUIformLite.FormBorderStyle = "FixedDialog"

    #region GUI elements
    $machineLabel = New-Object System.Windows.Forms.Label
    $machineLabel.Size = New-Object System.Drawing.Size(610, 20)
    $machineLabel.Location = New-Object System.Drawing.Point(0, 20)
    $machineLabel.Text = msrdGetLocalizedText "LiteModeMachine" # Machine type
    $machineLabel.TextAlign = "MiddleCenter"
    $machineLabel.Font = New-Object Drawing.Font($machineLabel.Font, [Drawing.FontStyle]::Bold)
    $global:msrdGUIformLite.Controls.Add($machineLabel)

    $global:btnColor = ""
    $global:btnIdleColor = "Lightgray"

    $btnAVD = New-Object System.Windows.Forms.Button
    $btnAVD.Size = New-Object System.Drawing.Size(150, 40)
    $btnAVD.Location = New-Object System.Drawing.Point(70, 40)
    $btnAVD.BackColor = "Lightblue"
    $btnAVD.Text = "Azure Virtual Desktop"
    $btnAVDToolTip = New-Object System.Windows.Forms.ToolTip
    $btnAVDToolTip.SetToolTip($btnAVD, $(msrdGetLocalizedText "btnTooltipAVD"))
    $global:msrdGUIformLite.Controls.Add($btnAVD)

    $global:btnAVDclick = $true
    $btnAVD.Add_Click({
        $global:btnColor = "Lightblue"
        msrdInitScenarioVars

        if ($global:btnAVDclick) {
            msrdShowHideItems -category "Role" -show $true
            msrdInitMachines -Machine @($true, $false, $false)

            $btnRDS.Enabled = $false; $btnW365.Enabled = $false
            $btnRDS.ResetBackColor(); $btnW365.ResetBackColor()
            $btnSource.Enabled = $true; $btnTarget.Enabled = $true
            $btnSource.BackColor = $global:btnColor; $btnTarget.BackColor = $global:btnColor

            $btnTarget.Text = msrdGetLocalizedText "LiteModeTarget"
            $btnTargetToolTip.SetToolTip($btnTarget, $(msrdGetLocalizedText "LiteModeTargetTooltip"))
        } else {
            msrdInitMachines
            msrdInitRoles

            $btnRDS.Enabled = $true; $btnW365.Enabled = $true
            $btnRDS.BackColor = "Pink"; $btnW365.BackColor = "Lightyellow"
            $btnSource.Enabled = $false; $btnTarget.Enabled = $false
            $btnSource.ResetBackColor(); $btnTarget.ResetBackColor()

            $global:btnSourceClick = $true; $global:btnTargetClick = $true;
            $global:btnProfilesClick = $true; $global:btnActivationClick = $true; $global:btnMSRAClick = $true; $global:btnSCardClick = $true;
            $global:btnIMEClick = $true; $global:btnTeamsClick = $true; $global:btnMSIXAAClick = $true; $global:btnHCIClick = $true;
            $global:btnDiagOnlyClick = $true
            $btnProfiles.Enabled = $false; $btnActivation.Enabled = $false; $btnMSRA.Enabled = $false; $btnSCard.Enabled = $false;
            $btnIME.Enabled = $false; $btnTeams.Enabled = $false; $btnMSIXAA.Enabled = $false; $btnHCI.Enabled = $false;
            $btnProfiles.ResetBackColor(); $btnActivation.ResetBackColor(); $btnMSRA.ResetBackColor(); $btnSCard.ResetBackColor();
            $btnIME.ResetBackColor(); $btnTeams.ResetBackColor(); $btnMSIXAA.ResetBackColor(); $btnHCI.ResetBackColor(); $btnDiagOnly.ResetBackColor(); $btnCore.ResetBackColor();

            $btnStart.Enabled = $false; $btnStart.ResetBackColor();

            $global:onlyDiag = $false
            $script:vCore = $script:varsCore
            msrdShowHideItems -category "Role" -show $false
        }
        $global:btnAVDclick = (-not $global:btnAVDclick)
    })

    $btnRDS = New-Object System.Windows.Forms.Button
    $btnRDS.Size = New-Object System.Drawing.Size(150, 40)
    $btnRDS.Location = New-Object System.Drawing.Point(230, 40)
    $btnRDS.BackColor = "Pink"
    $btnRDS.Text = "Remote Desktop Services"
    $btnRDSToolTip = New-Object System.Windows.Forms.ToolTip
    $btnRDSToolTip.SetToolTip($btnRDS, $(msrdGetLocalizedText "btnTooltipRDS"))
    $global:msrdGUIformLite.Controls.Add($btnRDS)

    $global:btnRDSclick = $true
    $btnRDS.Add_Click({
        $global:btnColor = "Pink"
        msrdInitScenarioVars

        if ($global:btnRDSclick) {
            msrdShowHideItems -category "Role" -show $true
            msrdInitMachines -Machine @($false, $true, $false)

            $btnAVD.Enabled = $false; $btnW365.Enabled = $false
            $btnAVD.ResetBackColor(); $btnW365.ResetBackColor()
            $btnSource.Enabled = $true; $btnTarget.Enabled = $true
            $btnSource.BackColor = $global:btnColor; $btnTarget.BackColor = $global:btnColor

            $btnTarget.Text = msrdGetLocalizedText "LiteModeTarget2"
            $btnTargetToolTip.SetToolTip($btnTarget, $(msrdGetLocalizedText "LiteModeTargetTooltip2"))
        } else {
            msrdInitMachines
            msrdInitRoles

            $btnAVD.Enabled = $true; $btnW365.Enabled = $true
            $btnAVD.BackColor = "Lightblue"; $btnW365.BackColor = "Lightyellow"
            $btnSource.Enabled = $false; $btnTarget.Enabled = $false
            $btnSource.ResetBackColor(); $btnTarget.ResetBackColor()

            $global:btnSourceClick = $true; $global:btnTargetClick = $true;
            $global:btnProfilesClick = $true; $global:btnActivationClick = $true; $global:btnMSRAClick = $true; $global:btnSCardClick = $true;
            $global:btnIMEClick = $true; $global:btnTeamsClick = $true; $global:btnMSIXAAClick = $true; $global:btnHCIClick = $true;
            $global:btnDiagOnlyClick = $true
            $btnProfiles.Enabled = $false; $btnActivation.Enabled = $false; $btnMSRA.Enabled = $false; $btnSCard.Enabled = $false;
            $btnIME.Enabled = $false; $btnTeams.Enabled = $false; $btnMSIXAA.Enabled = $false; $btnHCI.Enabled = $false; $btnDiagOnly.Enabled = $false;
            $btnProfiles.ResetBackColor(); $btnActivation.ResetBackColor(); $btnMSRA.ResetBackColor(); $btnSCard.ResetBackColor();
            $btnIME.ResetBackColor(); $btnTeams.ResetBackColor(); $btnMSIXAA.ResetBackColor(); $btnHCI.ResetBackColor(); $btnDiagOnly.ResetBackColor(); $btnCore.ResetBackColor();

            $btnStart.Enabled = $false; $btnStart.ResetBackColor();

            $global:onlyDiag = $false
            $script:vCore = $script:varsCore
            $btnTarget.Text = "Target machine / Host"
            msrdShowHideItems -category "Role" -show $false
        }
        $global:btnRDSclick = (-not $global:btnRDSclick)
    })

    $btnW365 = New-Object System.Windows.Forms.Button
    $btnW365.Size = New-Object System.Drawing.Size(150, 40)
    $btnW365.Location = New-Object System.Drawing.Point(390, 40)
    $btnW365.BackColor = "Lightyellow"
    $btnW365.Text = "Windows 365 Cloud PC"
    $btnW365ToolTip = New-Object System.Windows.Forms.ToolTip
    $btnW365ToolTip.SetToolTip($btnW365, $(msrdGetLocalizedText "btnTooltipW365"))
    $global:msrdGUIformLite.Controls.Add($btnW365)

    $global:btnW365click = $true
    $btnW365.Add_Click({
        $global:btnColor = "Lightyellow"
        msrdInitScenarioVars

        if ($global:btnW365click) {
            msrdShowHideItems -category "Role" -show $true
            msrdInitMachines -Machine @($false, $false, $true)

            $btnAVD.Enabled = $false; $btnRDS.Enabled = $false
            $btnAVD.ResetBackColor(); $btnRDS.ResetBackColor()
            $btnSource.Enabled = $true; $btnTarget.Enabled = $true
            $btnSource.BackColor = $global:btnColor; $btnTarget.BackColor = $global:btnColor

            $btnTarget.Text = msrdGetLocalizedText "LiteModeTarget"
            $btnTargetToolTip.SetToolTip($btnTarget, $(msrdGetLocalizedText "LiteModeTargetTooltip"))
        } else {
            msrdInitMachines
            msrdInitRoles

            $btnAVD.Enabled = $true; $btnRDS.Enabled = $true
            $btnAVD.BackColor = "Lightblue"; $btnRDS.BackColor = "Pink"
            $btnSource.Enabled = $false; $btnTarget.Enabled = $false
            $btnSource.ResetBackColor(); $btnTarget.ResetBackColor()

            $global:btnSourceClick = $true; $global:btnTargetClick = $true;
            $global:btnProfilesClick = $true; $global:btnActivationClick = $true; $global:btnMSRAClick = $true; $global:btnSCardClick = $true;
            $global:btnIMEClick = $true; $global:btnTeamsClick = $true; $global:btnMSIXAAClick = $true; $global:btnHCIClick = $true;
            $global:btnDiagOnlyClick = $true
            $btnProfiles.Enabled = $false; $btnActivation.Enabled = $false; $btnMSRA.Enabled = $false; $btnSCard.Enabled = $false;
            $btnIME.Enabled = $false; $btnTeams.Enabled = $false; $btnMSIXAA.Enabled = $false; $btnHCI.Enabled = $false; $btnDiagOnly.Enabled = $false;
            $btnProfiles.ResetBackColor(); $btnActivation.ResetBackColor(); $btnMSRA.ResetBackColor(); $btnSCard.ResetBackColor();
            $btnIME.ResetBackColor(); $btnTeams.ResetBackColor(); $btnMSIXAA.ResetBackColor(); $btnHCI.ResetBackColor(); $btnDiagOnly.ResetBackColor(); $btnCore.ResetBackColor();

            $btnStart.Enabled = $false; $btnStart.ResetBackColor();

            $global:onlyDiag = $false
            $script:vCore = $script:varsCore
            msrdShowHideItems -category "Role" -show $false
        }
        $global:btnW365click = (-not $global:btnW365click)
    })

    $roleLabel = New-Object System.Windows.Forms.Label
    $roleLabel.Size = New-Object System.Drawing.Size(610, 20)
    $roleLabel.Location = New-Object System.Drawing.Point(0, 100)
    $roleLabel.Text = msrdGetLocalizedText "LiteModeRole" # "Role"
    $roleLabel.Textalign = "MiddleCenter"
    $roleLabel.Font = New-Object Drawing.Font($roleLabel.Font, [Drawing.FontStyle]::Bold)
    $global:msrdGUIformLite.Controls.Add($roleLabel)

    $btnSource = New-Object System.Windows.Forms.Button
    $btnSource.Size = New-Object System.Drawing.Size(150, 40)
    $btnSource.Location = New-Object System.Drawing.Point(150, 120)
    $btnSource.Text = msrdGetLocalizedText "LiteModeSource"
    $btnSourceToolTip = New-Object System.Windows.Forms.ToolTip
    $btnSourceToolTip.SetToolTip($btnSource, $(msrdGetLocalizedText "LiteModeSourceTooltip"))
    $global:msrdGUIformLite.Controls.Add($btnSource)

    $global:btnSourceClick = $true
    $btnSource.Add_Click({
        msrdInitScenarioVars

        if ($global:btnSourceClick) {
            msrdShowHideItems -category "Scenario" -show $true
            msrdShowHideItems -category "Start" -show $true
            msrdInitRoles -Role @($true, $false)

            $btnTarget.Enabled = $false
            $btnTarget.ResetBackColor()

            $btnCore.BackColor = $global:btnColor;
            $btnProfiles.Enabled = $false; $btnActivation.Enabled = $false; $btnMSRA.Enabled = $false; $btnSCard.Enabled = $false;
            $btnIME.Enabled = $false; $btnTeams.Enabled = $false; $btnMSIXAA.Enabled = $false; $btnHCI.Enabled = $false; $btnDiagOnly.Enabled = $false;
            $btnProfiles.ResetBackColor(); $btnActivation.ResetBackColor(); $btnMSRA.ResetBackColor(); $btnSCard.ResetBackColor();
            $btnIME.ResetBackColor(); $btnTeams.ResetBackColor(); $btnMSIXAA.ResetBackColor(); $btnHCI.ResetBackColor();
            $btnDiagOnly.Enabled = $true; $btnDiagOnly.BackColor = $global:btnIdleColor;
            $btnStart.Enabled = $true; $btnStart.BackColor = $global:btnColor;
        } else {
            msrdInitRoles

            $btnTarget.Enabled = $true
            $btnTarget.BackColor = $global:btnColor
            $global:btnDiagOnlyClick = $true

            $btnCore.ResetBackColor();
            $btnProfiles.Enabled = $false; $btnActivation.Enabled = $false; $btnMSRA.Enabled = $false; $btnSCard.Enabled = $false;
            $btnIME.Enabled = $false; $btnTeams.Enabled = $false; $btnMSIXAA.Enabled = $false; $btnHCI.Enabled = $false;
            $btnProfiles.ResetBackColor(); $btnActivation.ResetBackColor(); $btnMSRA.ResetBackColor(); $btnSCard.ResetBackColor();
            $btnIME.ResetBackColor(); $btnTeams.ResetBackColor(); $btnMSIXAA.ResetBackColor(); $btnHCI.ResetBackColor();
            $btnDiagOnly.Enabled = $false; $btnDiagOnly.ResetBackColor();
            $btnStart.Enabled = $false; $btnStart.ResetBackColor();

            $global:onlyDiag = $false
            $script:vCore = $script:varsCore
            msrdShowHideItems -category "Scenario" -show $false
            msrdShowHideItems -category "Start" -show $false
        }
        $global:btnSourceClick = (-not $global:btnSourceClick)
    })

    $btnTarget = New-Object System.Windows.Forms.Button
    $btnTarget.Size = New-Object System.Drawing.Size(150, 40)
    $btnTarget.Location = New-Object System.Drawing.Point(310, 120)
    $btnTarget.Text = msrdGetLocalizedText "LiteModeTarget"
    $btnTargetToolTip = New-Object System.Windows.Forms.ToolTip
    $global:msrdGUIformLite.Controls.Add($btnTarget)

    $global:btnTargetClick = $true
    $btnTarget.Add_Click({
        msrdInitScenarioVars

        if ($global:btnTargetClick) {
            msrdShowHideItems -category "Scenario" -show $true
            msrdShowHideItems -category "Start" -show $true
            msrdInitRoles -Role @($false, $true)

            $btnSource.Enabled = $false
            $btnSource.ResetBackColor()

            if (-not $global:btnAVDClick) {
                $btnMSRA.Enabled = $true; $btnTeams.Enabled = $true;  $btnMSIXAA.Enabled = $true; $btnHCI.Enabled = $true;
                $btnMSRA.BackColor = $global:btnIdleColor; $btnTeams.BackColor = $global:btnIdleColor; $btnMSIXAA.BackColor = $global:btnIdleColor; $btnHCI.BackColor = $global:btnIdleColor;
            } elseif (-not $global:btnRDSClick) {
                $btnMSRA.Enabled = $true;
                $btnMSRA.BackColor = $global:btnIdleColor;
            } elseif (-not $global:btnW365Click) {
                $btnTeams.Enabled = $true;
                $btnTeams.BackColor = $global:btnIdleColor;
            }

            $btnCore.BackColor = $global:btnColor;
            $btnProfiles.Enabled = $true; $btnActivation.Enabled = $true; $btnSCard.Enabled = $true; $btnIME.Enabled = $true;
            $btnProfiles.BackColor = $global:btnIdleColor; $btnActivation.BackColor = $global:btnIdleColor; $btnSCard.BackColor = $global:btnIdleColor; $btnIME.BackColor = $global:btnIdleColor;
            $btnDiagOnly.Enabled = $true; $btnDiagOnly.BackColor = $global:btnIdleColor;
            $btnStart.Enabled = $true; $btnStart.BackColor = $global:btnColor;

        } else {
            msrdInitRoles

            $btnSource.Enabled = $true
            $btnSource.BackColor = $global:btnColor
            $global:btnDiagOnlyClick = $true

            $btnCore.ResetBackColor();
            $btnProfiles.Enabled = $false; $btnActivation.Enabled = $false; $btnMSRA.Enabled = $false; $btnSCard.Enabled = $false;
            $btnIME.Enabled = $false; $btnTeams.Enabled = $false; $btnMSIXAA.Enabled = $false; $btnHCI.Enabled = $false;
            $btnProfiles.ResetBackColor(); $btnActivation.ResetBackColor(); $btnMSRA.ResetBackColor(); $btnSCard.ResetBackColor();
            $btnIME.ResetBackColor(); $btnTeams.ResetBackColor(); $btnMSIXAA.ResetBackColor(); $btnHCI.ResetBackColor();
            $btnDiagOnly.Enabled = $false; $btnDiagOnly.ResetBackColor();
            $btnStart.Enabled = $false; $btnStart.ResetBackColor();

            $global:onlyDiag = $false
            $script:vCore = $script:varsCore
            msrdShowHideItems -category "Scenario" -show $false
            msrdShowHideItems -category "Start" -show $false
        }
        $global:btnTargetClick = (-not $global:btnTargetClick)
    })

    $scenarioLabel = New-Object System.Windows.Forms.Label
    $scenarioLabel.Size = New-Object System.Drawing.Size(610, 20)
    $scenarioLabel.Location = New-Object System.Drawing.Point(0, 180)
    $scenarioLabel.Text = msrdGetLocalizedText "LiteModeScenarios" # "Scenarios"
    $scenarioLabel.TextAlign = "MiddleCenter"
    $scenarioLabel.Font = New-Object Drawing.Font($scenarioLabel.Font, [Drawing.FontStyle]::Bold)
    $global:msrdGUIformLite.Controls.Add($scenarioLabel)

    $btnCore = New-Object System.Windows.Forms.Button
    $btnCore.Size = New-Object System.Drawing.Size(100, 40)
    $btnCore.Location = New-Object System.Drawing.Point(35, 200)
    $btnCore.Text = "Core"
    $btnCore.Enabled = $false
    $global:msrdGUIformLite.Controls.Add($btnCore)

    $btnProfiles = New-Object System.Windows.Forms.Button
    $btnProfiles.Size = New-Object System.Drawing.Size(100, 40)
    $btnProfiles.Location = New-Object System.Drawing.Point(145, 200)
    $btnProfiles.Text = "Profiles"
    $btnProfilesToolTip = New-Object System.Windows.Forms.ToolTip
    $btnProfilesToolTip.SetToolTip($btnProfiles, "$(msrdGetLocalizedText 'btnTooltipProfiles')")
    $global:msrdGUIformLite.Controls.Add($btnProfiles)

    $global:btnProfilesClick = $true
    $btnProfiles.Add_Click({
        if ($global:btnProfilesClick) {
            $script:vProfiles = $script:varsProfiles; $btnProfiles.BackColor = $global:btnColor;
        } else {
            $script:vProfiles = $varsNO; $btnProfiles.ResetBackColor();
        }
        $global:btnProfilesClick = (-not $global:btnProfilesClick)
    })

    $btnActivation = New-Object System.Windows.Forms.Button
    $btnActivation.Size = New-Object System.Drawing.Size(100, 40)
    $btnActivation.Location = New-Object System.Drawing.Point(255, 200)
    $btnActivation.Text = "Activation"
    $btnActivationToolTip = New-Object System.Windows.Forms.ToolTip
    $btnActivationToolTip.SetToolTip($btnActivation, "$(msrdGetLocalizedText 'btnTooltipActivation')")
    $global:msrdGUIformLite.Controls.Add($btnActivation)

    $global:btnActivationClick = $true
    $btnActivation.Add_Click({
        if ($global:btnActivationClick) {
            $script:vActivation = $script:varsActivation; $btnActivation.BackColor = $global:btnColor;
        } else {
            $script:vActivation = $varsNO; $btnActivation.ResetBackColor();
        }
        $global:btnActivationClick = (-not $global:btnActivationClick)
    })

    $btnMSRA = New-Object System.Windows.Forms.Button
    $btnMSRA.Size = New-Object System.Drawing.Size(100, 40)
    $btnMSRA.Location = New-Object System.Drawing.Point(365, 200)
    $btnMSRA.Text = "Remote Assistance"
    $btnMSRAToolTip = New-Object System.Windows.Forms.ToolTip
    $btnMSRAToolTip.SetToolTip($btnMSRA, "$(msrdGetLocalizedText 'btnTooltipMSRA')")
    $global:msrdGUIformLite.Controls.Add($btnMSRA)

    $global:btnMSRAClick = $true
    $btnMSRA.Add_Click({
        if ($global:btnMSRAClick) {
            $script:vMSRA = $script:varsMSRA; $btnMSRA.BackColor = $global:btnColor;
        } else {
            $script:vMSRA = $varsNO; $btnMSRA.ResetBackColor();
        }
        $global:btnMSRAClick = (-not $global:btnMSRAClick)
    })

    $btnSCard = New-Object System.Windows.Forms.Button
    $btnSCard.Size = New-Object System.Drawing.Size(100, 40)
    $btnSCard.Location = New-Object System.Drawing.Point(475, 200)
    $btnSCard.Text = "Smart Card"
    $btnSCardToolTip = New-Object System.Windows.Forms.ToolTip
    $btnSCardToolTip.SetToolTip($btnSCard, "$(msrdGetLocalizedText 'btnTooltipSCard')")
    $global:msrdGUIformLite.Controls.Add($btnSCard)

    $global:btnSCardClick = $true
    $btnSCard.Add_Click({
        if ($global:btnSCardClick) {
            $script:vSCard = $script:varsSCard; $btnSCard.BackColor = $global:btnColor;
        } else {
            $script:vSCard = $varsNO; $btnSCard.ResetBackColor();
        }
        $global:btnSCardClick = (-not $global:btnSCardClick)
    })

    $btnIME = New-Object System.Windows.Forms.Button
    $btnIME.Size = New-Object System.Drawing.Size(100, 40)
    $btnIME.Location = New-Object System.Drawing.Point(35, 250)
    $btnIME.Text = "IME"
    $btnIMEToolTip = New-Object System.Windows.Forms.ToolTip
    $btnIMEToolTip.SetToolTip($btnIME, "$(msrdGetLocalizedText 'btnTooltipIME')")
    $global:msrdGUIformLite.Controls.Add($btnIME)

    $global:btnIMEClick = $true
    $btnIME.Add_Click({
        if ($global:btnIMEClick) {
            $script:vIME = $script:varsIME; $btnIME.BackColor = $global:btnColor;
        } else {
            $script:vIME = $varsNO; $btnIME.ResetBackColor();
        }
        $global:btnIMEClick = (-not $global:btnIMEClick)
    })

    $btnTeams = New-Object System.Windows.Forms.Button
    $btnTeams.Size = New-Object System.Drawing.Size(100, 40)
    $btnTeams.Location = New-Object System.Drawing.Point(145, 250)
    $btnTeams.Text = "Teams"
    $btnTeamsToolTip = New-Object System.Windows.Forms.ToolTip
    $btnTeamsToolTip.SetToolTip($btnTeams, "$(msrdGetLocalizedText 'btnTooltipTeams')")
    $global:msrdGUIformLite.Controls.Add($btnTeams)

    $global:btnTeamsClick = $true
    $btnTeams.Add_Click({
        if ($global:btnTeamsClick) {
            $script:vTeams = $script:varsTeams; $btnTeams.BackColor = $global:btnColor;
        } else {
            $script:vTeams = $varsNO; $btnTeams.ResetBackColor();
        }
        $global:btnTeamsClick = (-not $global:btnTeamsClick)
    })

    $btnMSIXAA = New-Object System.Windows.Forms.Button
    $btnMSIXAA.Size = New-Object System.Drawing.Size(100, 40)
    $btnMSIXAA.Location = New-Object System.Drawing.Point(255, 250)
    $btnMSIXAA.Text = "App Attach"
    $btnMSIXAAToolTip = New-Object System.Windows.Forms.ToolTip
    $btnMSIXAAToolTip.SetToolTip($btnMSIXAA, "$(msrdGetLocalizedText 'btnTooltipMSIXAA')")
    $global:msrdGUIformLite.Controls.Add($btnMSIXAA)

    $global:btnMSIXAAClick = $true
    $btnMSIXAA.Add_Click({
        if ($global:btnMSIXAAClick) {
            $script:vMSIXAA = $script:varsMSIXAA; $btnMSIXAA.BackColor = $global:btnColor;
        } else {
            $script:vMSIXAA = $varsNO; $btnMSIXAA.ResetBackColor();
        }
        $global:btnMSIXAAClick = (-not $global:btnMSIXAAClick)
    })

    $btnHCI = New-Object System.Windows.Forms.Button
    $btnHCI.Size = New-Object System.Drawing.Size(100, 40)
    $btnHCI.Location = New-Object System.Drawing.Point(365, 250)
    $btnHCI.Text = "Azure Stack HCI"
    $btnHCIToolTip = New-Object System.Windows.Forms.ToolTip
    $btnHCIToolTip.SetToolTip($btnHCI, "$(msrdGetLocalizedText 'btnTooltipHCI')")
    $global:msrdGUIformLite.Controls.Add($btnHCI)

    $global:btnHCIClick = $true
    $btnHCI.Add_Click({
        if ($global:btnHCIClick) {
            $script:vHCI = $script:varsHCI; $btnHCI.BackColor = $global:btnColor;
        } else {
            $script:vHCI = $varsNO; $btnHCI.ResetBackColor();
        }
        $global:btnHCIClick = (-not $global:btnHCIClick)
    })

    $btnDiagOnly = New-Object System.Windows.Forms.Button
    $btnDiagOnly.Size = New-Object System.Drawing.Size(100, 40)
    $btnDiagOnly.Location = New-Object System.Drawing.Point(475, 250)
    $btnDiagOnly.Text = "Diagnostics Only"
    $btnDiagOnlyToolTip = New-Object System.Windows.Forms.ToolTip
    $btnDiagOnlyToolTip.SetToolTip($btnDiagOnly, "$(msrdGetLocalizedText 'btnTooltipDiagOnly')")
    $global:msrdGUIformLite.Controls.Add($btnDiagOnly)

    $global:btnDiagOnlyClick = $true
    $btnDiagOnly.Add_Click({
        if ($global:btnDiagOnlyClick) {
            $global:onlyDiag = $true
            $script:vCore = $script:varsNO

            $btnDiagOnly.BackColor = $global:btnColor; $btnCore.ResetBackColor();
            $btnProfiles.Enabled = $false; $btnActivation.Enabled = $false; $btnMSRA.Enabled = $false; $btnSCard.Enabled = $false;
            $btnIME.Enabled = $false; $btnTeams.Enabled = $false; $btnMSIXAA.Enabled = $false; $btnHCI.Enabled = $false;
            $btnProfiles.ResetBackColor(); $btnActivation.ResetBackColor(); $btnMSRA.ResetBackColor(); $btnSCard.ResetBackColor();
            $btnIME.ResetBackColor(); $btnTeams.ResetBackColor(); $btnMSIXAA.ResetBackColor(); $btnHCI.ResetBackColor();
        } else {
            $global:onlyDiag = $false
            $script:vCore = $script:varsCore

            if (-not $btnTargetClick) {
                if (-not $global:btnAVDClick) {
                    $btnMSRA.Enabled = $true; $btnTeams.Enabled = $true;  $btnMSIXAA.Enabled = $true; $btnHCI.Enabled = $true;
                    $btnMSRA.BackColor = $global:btnIdleColor; $btnTeams.BackColor = $global:btnIdleColor; $btnMSIXAA.BackColor = $global:btnIdleColor; $btnHCI.BackColor = $global:btnIdleColor;
                } elseif (-not $global:btnRDSClick) {
                    $btnMSRA.Enabled = $true;
                    $btnMSRA.BackColor = $global:btnIdleColor;
                } elseif (-not $global:btnW365Click) {
                    $btnTeams.Enabled = $true;
                    $btnTeams.BackColor = $global:btnIdleColor;
                }
                $btnProfiles.Enabled = $true; $btnActivation.Enabled = $true; $btnSCard.Enabled = $true; $btnIME.Enabled = $true;
                $btnProfiles.BackColor = $global:btnIdleColor; $btnActivation.BackColor = $global:btnIdleColor; $btnSCard.BackColor = $global:btnIdleColor; $btnIME.BackColor = $global:btnIdleColor;
            }

            $global:btnProfilesClick = $true; $global:btnActivationClick = $true; $global:btnMSRAClick = $true; $global:btnSCardClick = $true;
            $global:btnIMEClick = $true; $global:btnTeamsClick = $true; $global:btnMSIXAAClick = $true; $global:btnHCIClick = $true;
            $btnDiagOnly.BackColor = $global:btnIdleColor; $btnCore.BackColor = $global:btnColor;
        }
        $global:btnDiagOnlyClick = (-not $global:btnDiagOnlyClick)
    })

    $startLabel = New-Object System.Windows.Forms.Label
    $startLabel.Size = New-Object System.Drawing.Size(610, 20)
    $startLabel.Location = New-Object System.Drawing.Point(0, 310)
    $startLabel.Text = msrdGetLocalizedText "LiteModeStart" # "Start"
    $startLabel.TextAlign = "MiddleCenter"
    $startLabel.Font = New-Object Drawing.Font($startLabel.Font, [Drawing.FontStyle]::Bold)
    $global:msrdGUIformLite.Controls.Add($startLabel)

    $btnStart = New-Object System.Windows.Forms.Button
    $btnStart.Size = New-Object System.Drawing.Size(120, 40)
    $btnStart.Location = New-Object System.Drawing.Point(245, 330)
    $btnStart.Text = msrdGetLocalizedText "Start"
    $btnStartToolTip = New-Object System.Windows.Forms.ToolTip
    $btnStartToolTip.SetToolTip($btnStart, "$(msrdGetLocalizedText 'RunMenu')")
    $global:msrdGUIformLite.Controls.Add($btnStart)

    $btnStart.Add_Click({ msrdStartBtnCollect })

    msrdShowHideItems -category "Role" -show $false
    msrdShowHideItems -category "Scenario" -show $false
    msrdShowHideItems -category "Start" -show $false

    # Create the "Show console" checkbox and label
    $checkBoxShowConsole = New-Object System.Windows.Forms.CheckBox
    $checkBoxShowConsole.Text = msrdGetLocalizedText "LiteModeHideConsole"
    $checkBoxShowConsole.Location = New-Object System.Drawing.Point(20, 385)
    $checkBoxShowConsole.Size = New-Object System.Drawing.Size(150, 20)
    $global:msrdGUIformLite.Controls.Add($checkBoxShowConsole)
    $checkBoxShowConsole.Add_Click({
        if ($checkBoxShowConsole.Checked) {
            msrdShowConsoleWindow -status $true
            $checkBoxShowConsole.Checked = $true
        } else {
            msrdShowConsoleWindow -status $false
            $checkBoxShowConsole.Checked = $false
        }
    })

    # Create the "Advanced Mode" checkbox and label
    $checkBoxAdvancedMode = New-Object System.Windows.Forms.CheckBox
    $checkBoxAdvancedMode.Text = msrdGetLocalizedText "LiteModeAdvanced" # Advanced Mode
    $checkBoxAdvancedMode.Location = New-Object System.Drawing.Point(495, 385)
    $checkBoxAdvancedMode.Size = New-Object System.Drawing.Size(150, 20)
    $global:msrdGUIformLite.Controls.Add($checkBoxAdvancedMode)
    $checkBoxAdvancedMode.Add_Click({
        if ($checkBoxAdvancedMode.Checked) {
            try {
                $ScriptFile = $global:msrdScriptpath + "\MSRD-Collect.ps1"
                Start-Process PowerShell.exe -ArgumentList "$ScriptFile" -NoNewWindow
                msrdUpdateConfigFile -configFile "Config\MSRDC-Config.json" -key "UILiteMode" -value 0
                If (($Null -ne $global:msrdTempCommandErrorFile) -and (Test-Path -Path $global:msrdTempCommandErrorFile)) { Remove-Item $global:msrdTempCommandErrorFile -Force | Out-Null }
                If ($global:fQuickEditCodeExist) { [msrdDisableConsoleQuickEdit]::SetQuickEdit($False) | Out-Null }
                if (($global:msrdGUIformLite -and $global:msrdGUIformLite.Visible)) { $global:msrdGUIformLite.Close() } else { Exit }
            } catch {
                $failedCommand = $_.InvocationInfo.Line.TrimStart()
                msrdLogException ("$(msrdGetLocalizedText "errormsg") $failedCommand") -ErrObj $_
            }
        }
    })


    # Iterate through all controls on the form
    foreach ($control in $global:msrdGUIformLite.Controls) {
        # Check if the control is a Button
        if (($control -is [System.Windows.Forms.Button]) -or ($control -is [System.Windows.Forms.CheckBox])) {
            $control.Add_MouseEnter({ $this.Cursor = [System.Windows.Forms.Cursors]::Hand })
            $control.Add_MouseLeave({ $this.Cursor = [System.Windows.Forms.Cursors]::Default })
        }
    }
    #endregion GUI elements


    #region BottomOptions

    $global:msrdStatusBar = New-Object System.Windows.Forms.StatusStrip
    $global:msrdStatusBarLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
    $global:msrdStatusBarLabel.Text = msrdGetLocalizedText "Ready"
    $global:msrdStatusBar.Items.Add($global:msrdStatusBarLabel) | Out-Null
    $global:msrdGUIformLite.Controls.Add($global:msrdStatusBar)

    $global:msrdProgbar = New-Object System.Windows.Forms.ProgressBar
    $global:msrdProgbar.Location  = New-Object System.Drawing.Point(10,415)
    $global:msrdProgbar.Size = New-Object System.Drawing.Size(595,15)
    $global:msrdProgbar.Anchor = 'Left,Bottom'
    $global:msrdProgbar.DataBindings.DefaultDataSourceUpdateMode = 0
    $global:msrdProgbar.Step = 1
    $global:msrdGUIformLite.Controls.Add($global:msrdProgbar)

    $feedbackLinkLite = New-Object System.Windows.Forms.LinkLabel
    $feedbackLinkLite.Location = [System.Drawing.Point]::new(195, 385)
    $feedbackLinkLite.Size = [System.Drawing.Point]::new(180, 20)
    $feedbackLinkLite.LinkColor = [System.Drawing.Color]::Blue
    $feedbackLinkLite.ActiveLinkColor = [System.Drawing.Color]::Red
    $feedbackLinkLite.Text = msrdGetLocalizedText "feedbackLink"
    $feedbackLinkLite.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $feedbackLinkLite.Add_Click({ [System.Diagnostics.Process]::Start('https://aka.ms/MSRD-Collect-Feedback') })
    $feedbackLinkLiteToolTip = New-Object System.Windows.Forms.ToolTip
    $feedbackLinkLiteToolTip.SetToolTip($feedbackLinkLite, "$(msrdGetLocalizedText 'feedbackLink')")
    $global:msrdGUIformLite.Controls.Add($feedbackLinkLite)

    #endregion BottomOptions

    if ($global:msrdConfig.ShowConsoleWindow -eq 1) {
        msrdShowConsoleWindow -status $true
        $checkBoxShowConsole.Checked = $true
    } else {
        msrdShowConsoleWindow -status $false
        $checkBoxShowConsole.Checked = $false
    }

    $global:msrdGUIformLite.Add_Shown({
        $btnSource.Enabled = $false
        $btnTarget.Enabled = $false
        $btnProfiles.Enabled = $false
        $btnActivation.Enabled = $false
        $btnMSRA.Enabled = $false
        $btnSCard.Enabled = $false
        $btnIME.Enabled = $false
        $btnTeams.Enabled = $false
        $btnMSIXAA.Enabled = $false
        $btnHCI.Enabled = $false
        $btnStart.Enabled = $false
    })

    $global:msrdGUIformLite.Add_Closing({
        If (($Null -ne $global:msrdTempCommandErrorFile) -and (Test-Path -Path $global:msrdTempCommandErrorFile)) { Remove-Item $global:msrdTempCommandErrorFile -Force | Out-Null }
        If ($global:fQuickEditCodeExist) { [msrdDisableConsoleQuickEdit]::SetQuickEdit($False) | Out-Null }
    })

    $global:msrdGUIformLite.ShowDialog() | Out-Null
    msrdShowConsoleWindow -status $true -nocfg $true
}


Export-ModuleMember -Function msrdAVDCollectGUILite
# SIG # Begin signature block
# MIIoRQYJKoZIhvcNAQcCoIIoNjCCKDICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCEcm0KSHEkcb6s
# 1KduejRYXRjrOhkDYU0ABdM0hP+e7qCCDXYwggX0MIID3KADAgECAhMzAAADrzBA
# DkyjTQVBAAAAAAOvMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwOTAwWhcNMjQxMTE0MTkwOTAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOS8s1ra6f0YGtg0OhEaQa/t3Q+q1MEHhWJhqQVuO5amYXQpy8MDPNoJYk+FWA
# hePP5LxwcSge5aen+f5Q6WNPd6EDxGzotvVpNi5ve0H97S3F7C/axDfKxyNh21MG
# 0W8Sb0vxi/vorcLHOL9i+t2D6yvvDzLlEefUCbQV/zGCBjXGlYJcUj6RAzXyeNAN
# xSpKXAGd7Fh+ocGHPPphcD9LQTOJgG7Y7aYztHqBLJiQQ4eAgZNU4ac6+8LnEGAL
# go1ydC5BJEuJQjYKbNTy959HrKSu7LO3Ws0w8jw6pYdC1IMpdTkk2puTgY2PDNzB
# tLM4evG7FYer3WX+8t1UMYNTAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQURxxxNPIEPGSO8kqz+bgCAQWGXsEw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMTgyNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAISxFt/zR2frTFPB45Yd
# mhZpB2nNJoOoi+qlgcTlnO4QwlYN1w/vYwbDy/oFJolD5r6FMJd0RGcgEM8q9TgQ
# 2OC7gQEmhweVJ7yuKJlQBH7P7Pg5RiqgV3cSonJ+OM4kFHbP3gPLiyzssSQdRuPY
# 1mIWoGg9i7Y4ZC8ST7WhpSyc0pns2XsUe1XsIjaUcGu7zd7gg97eCUiLRdVklPmp
# XobH9CEAWakRUGNICYN2AgjhRTC4j3KJfqMkU04R6Toyh4/Toswm1uoDcGr5laYn
# TfcX3u5WnJqJLhuPe8Uj9kGAOcyo0O1mNwDa+LhFEzB6CB32+wfJMumfr6degvLT
# e8x55urQLeTjimBQgS49BSUkhFN7ois3cZyNpnrMca5AZaC7pLI72vuqSsSlLalG
# OcZmPHZGYJqZ0BacN274OZ80Q8B11iNokns9Od348bMb5Z4fihxaBWebl8kWEi2O
# PvQImOAeq3nt7UWJBzJYLAGEpfasaA3ZQgIcEXdD+uwo6ymMzDY6UamFOfYqYWXk
# ntxDGu7ngD2ugKUuccYKJJRiiz+LAUcj90BVcSHRLQop9N8zoALr/1sJuwPrVAtx
# HNEgSW+AKBqIxYWM4Ev32l6agSUAezLMbq5f3d8x9qzT031jMDT+sUAoCw0M5wVt
# CUQcqINPuYjbS1WgJyZIiEkBMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGiUwghohAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAOvMEAOTKNNBUEAAAAAA68wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIFUcYD8PpPFgpwUwvO6S3e0l
# 9GCefQYZyN3whkFkQF0kMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAWp49ri7kO1MsjfGdMRLfU9H4QX7F0dOTFC4VCTnVFAyItCD1wSwbRqQv
# iH5Tg2e+sF/QPSRcn2bkHV5ZG6zH/YxS/f93XJ74LykPfr48c2jubvUGB9XTPVmz
# nI8sZthBijyq6ieyWiuyLiPI9Iivtoom+4yj1WD77NBbczXJ9FFt8hne0aYD1fvK
# Scmh1eR/G6YSP0jLCglQB3HyPaLlIt8Sis6aVIKrvlLcx37doEAh/89erBbUAy1H
# /DiD0Tzv/WHSUMplXLnOOj4UV8+eP9DoJmMeutilljTsOLGEXbyZVNEdjbQEzz2D
# GFcxiybxQmmLH5dFTS7/FeQuJMX62qGCF68wgherBgorBgEEAYI3AwMBMYIXmzCC
# F5cGCSqGSIb3DQEHAqCCF4gwgheEAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFZBgsq
# hkiG9w0BCRABBKCCAUgEggFEMIIBQAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCC8eKE3e/x+HdOzO6JO2fdvPdCwHwH99+TEz5aNf0Nm9wIGZuteeNyV
# GBIyMDI0MDkyNzA3Mzc1OC42NlowBIACAfSggdmkgdYwgdMxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVs
# YW5kIE9wZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNO
# OjU5MUEtMDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNloIIR/jCCBygwggUQoAMCAQICEzMAAAH0F0aFwMs/OeUAAQAAAfQwDQYJ
# KoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjQw
# NzI1MTgzMDU5WhcNMjUxMDIyMTgzMDU5WjCB0zELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3Bl
# cmF0aW9ucyBMaW1pdGVkMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046NTkxQS0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCnCE4TptCAL2qriMkZfYDX
# Kg5t+TSp61DySSP7mbftYHEOWxnmgmeN/Meymo+I4RXNnbLbKAaA1nf/F1lA3t/0
# DVanUB2HmoddlmHdIFfwAG5zr1NvdwnkoJlxcOy5/CZd4KPzUTMkQhmq5V1XxJOV
# C54H9vUwhi3lEqKze7DN2V9KXRyQdsbOg73VhMqDogTGopiiMat4KimcgrE6+Svl
# VmyPZ/3kFvUsYS+6EEib8LsnKy8m8FlY22uynPJdWe6j6QMTJnCmSmGxHxm92L6z
# +lCKh+Z1tbVSrNaWpdBWChhdtpiQTJpKH+F4G3CPW2574ty45wcA+BvBm9AuSwpo
# rjqiS2t6A5Hh7SJywaIBZH0gv6fLiaUJQ0DzgXsYQRY4S+JuKDvCytNrplvO4yzJ
# OLYDPio9XdBGQWDFJunhHg4QqeKfwnPhcsjXBeEGEikwZ8DcFPznSepqbNKIPkvm
# nH5W18KLQwlNLYsMXU9pVnCXJVkhWNUcryiHYdgb1PboWNH38jzmLkTHGaEenEzZ
# n5SEl5kDovPjnab/7GsDjGt1hqzlybsVSHLbis8tUf4XL5nLAcCn1z2hZOu2N8gq
# osi9i2AlzjVDxbFtk9HsHW5+3wEWy/PZ05IuTE8MtxdbLXoA3Lve/SKkLEDBQQL2
# GyyLQt0HxOGI1//gD5FnywIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFCt0ZaEK0Sw+
# J3UsnOxNotMpBt+bMB8GA1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8G
# A1UdHwRYMFYwVKBSoFCGTmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMv
# Y3JsL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBs
# BggrBgEFBQcBAQRgMF4wXAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0
# LmNvbS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUy
# MDIwMTAoMSkuY3J0MAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwDgYDVR0PAQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUAA4ICAQDdwdIPEkpQOyBp
# wh9FfrS6A4NKGwGrC0RRFRtRd4OZhhJrmgWPfhG6NbeA54K385sM7jm9+mdgbk5L
# lijDCwXDX2CIIjolX5xwb+qozTyfEBJvPBa2q2ivNCImH26mwThNVl4pheZvLHtY
# 3211tUisJ6VWPs/qJ8wdNIu3oGbKhLbGULZx+Ao88DXe9Ld66pSXrPB7sYCGN+M1
# eMqUThI1Ym92qCu/QZREqOqZqY2+GZIlqd7pNjOl0MJ6Crxp2UYfzkjURYqZ8RFv
# WXMrLk4w7Z70iQCW/J2lS6fQLew0S2nR6GWJPRKtqryNxhUMfgDYL8xssEjCKSPC
# IUZDhKUUtPZOBvga++lxZXMHHAOj0hEHCnOeBvLNuGH3lRU6tAvattYescNITd2B
# 0vbK5odGBjsdhguzku2zfTBT066Hw3nhFS1roYVkXHkDi4hODIlxV1ZVo3SqOzR4
# SPATI1S/RxEu4dYkF6OQx7epECG8KOeGujsMZFZoiV3J/NmqWfoWyctDduX5m9Ul
# ZNgm4v4hksjZKLcishF+Nxyfb1fYFf+/PYpxi5siMrpd9i+tlA3hcpue9KoE0DAg
# 9jbEl4Hij08MQUjatw9otTLPkhXsk/clGmCDfGxSq8UeVIbq4whaPAfQZAgjCsLb
# NHL6U1mw4qeu7LIcxBM/uPLlT3aoQTCCB3EwggVZoAMCAQICEzMAAAAVxedrngKb
# SZkAAAAAABUwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmlj
# YXRlIEF1dGhvcml0eSAyMDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIy
# NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXI
# yjVX9gF/bErg4r25PhdgM/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjo
# YH1qUoNEt6aORmsHFPPFdvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1y
# aa8dq6z2Nr41JmTamDu6GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v
# 3byNpOORj7I5LFGc6XBpDco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pG
# ve2krnopN6zL64NF50ZuyjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viS
# kR4dPf0gz3N9QZpGdc3EXzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYr
# bqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlM
# jgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSL
# W6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AF
# emzFER1y7435UsSFF5PAPBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIu
# rQIDAQABo4IB3TCCAdkwEgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIE
# FgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWn
# G1M1GelyMFwGA1UdIARVMFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEW
# M2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5
# Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBi
# AEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV
# 9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3Js
# Lm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAx
# MC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2
# LTIzLmNydDANBgkqhkiG9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv
# 6lwUtj5OR2R4sQaTlz0xM7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZn
# OlNN3Zi6th542DYunKmCVgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1
# bSNU5HhTdSRXud2f8449xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4
# rPf5KYnDvBewVIVCs/wMnosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU
# 6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDF
# NLB62FD+CljdQDzHVG2dY3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/
# HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdU
# CbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKi
# excdFYmNcP7ntdAoGokLjzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTm
# dHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZq
# ELQdVTNYs6FwZvKhggNZMIICQQIBATCCAQGhgdmkgdYwgdMxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVs
# YW5kIE9wZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNO
# OjU5MUEtMDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQC/4tn9WDSzXtd6TiIb1H1z/v4AjqCBgzCB
# gKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUA
# AgUA6qBojjAiGA8yMDI0MDkyNjIzMTExMFoYDzIwMjQwOTI3MjMxMTEwWjB3MD0G
# CisGAQQBhFkKBAExLzAtMAoCBQDqoGiOAgEAMAoCAQACAgaiAgH/MAcCAQACAhJW
# MAoCBQDqoboOAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAI
# AgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQELBQADggEBALiBYgSs7ODN
# Da4xwRKfvcGQ8gqzNqhFQYvx50CvJvZXGLwXRSs+3ZvxV1izPE4/jwVRPtPP/u8q
# bxsTDzX5n7TcUPJtWRVKReNSi2Lb2jYg2edi3qcWMI0gYxKMvWJEJhWNB8miaNP1
# YfM95CUiexMfXmAbmKL3fEnzfSlRzErn63V0AKmgtphho42iRb/aTGn4/XPz1WZB
# hyJtxMShSKovadwrlorUTT6erwalu0D+5+hv1VJTDtHD+SWFQZVSh7rUNVuUQ/9A
# iuGQiKCj6d0Oth95QkGz8GG4SQKnCuA6bg7c45E71HazJ2o+nEtQFSM7HfRao9li
# B3mz25FL4DgxggQNMIIECQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0Eg
# MjAxMAITMwAAAfQXRoXAyz855QABAAAB9DANBglghkgBZQMEAgEFAKCCAUowGgYJ
# KoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCAE5NWWWR2e
# RPWXwI/YaP2TEHUL6Ho0XETv3zAZtHKxUzCB+gYLKoZIhvcNAQkQAi8xgeowgecw
# geQwgb0EID9YwnxuJpPqeO+SScHxDuFJAiLzKzq8gG9mDrREGNZrMIGYMIGApH4w
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAH0F0aFwMs/OeUAAQAA
# AfQwIgQg//57HU8fhvsbGJwpaidgrRhScD/b08+rJKd+zDluRz8wDQYJKoZIhvcN
# AQELBQAEggIAC/XFovkt/VwOcMLne8fKEGXXoEVLigm7yUHJIXvxl8P+OiVvke0l
# okQ3ggHkUw6FjRnB1WlQeksYMUjhCtnXEHXD2ogsezmToCS9ov/8LoU9ZfWKzCR0
# 6bgPkBhqJf4mweSBqlgUw74Z1VmVW1tGg+8V1DAoA5snPXYr2SH0jZm05nd84Wgx
# gL4Pw6y52h+tcfoN8LrQE/tsekB+IopFyhzsvZuBTtAjnxsP6ixd0/ftRd28NtEE
# SUqfLrp0hnoSDYxDBaaeZcbcWmA0MADxE3eVNJ6NAjGelk2UvIJ7csuLuJ2Wmwaq
# UT0I/NgY/fNfP5M8XCfBvfLn3N28+xkSIwRjl6wLUnM6UD7g4SvL1e67bcaSsLCd
# AVq9NlSGAS8cX2ZwZ+WEPkbcTA/pXlnNHJvRvx2WX8IWyGYS+5d7DdRxoR2i7PuU
# AnDONp1casJh4seYgzFTVGmAlcYQL78rOzhDtFC1Ml1ru4y5nh5eiC2D3y+TE88u
# gHfD6+8RABh4l5Hawaxz2pIXONSfnuzgD2m28D1SouDl3TfhYPO3ey88Ff+ZMWOG
# hEbrNMliKH98McYW193iKqdBRg7ojIhRT0NKXjkhx/gVsl2ReSJRwHHxQbYa6Mgr
# O96YSR7Agaim/BiwzWHWrtdlvYgyrNVzSMZ0t4CllLj1Z+3hpTtH8Q4=
# SIG # End signature block
